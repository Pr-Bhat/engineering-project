-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 30, 2018 at 04:52 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vehicles_conveyor`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(15) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`cid`, `cname`, `username`, `password`) VALUES
(1, 'maruti', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `assign`
--

CREATE TABLE IF NOT EXISTS `assign` (
  `assign_num` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign`
--

INSERT INTO `assign` (`assign_num`, `location`, `qty`, `date`, `status`) VALUES
('104529', 'mysore', 1, '2018-12-13', 'Delivery'),
('d1', 'd1', 0, '0121-12-12', 'Dispatch'),
('156654', 'ujire', 0, '0001-12-11', 'processing');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phno` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`cid`, `cname`, `address`, `username`, `password`, `email`, `phno`) VALUES
(27, 'c2', 'c2', 'c2', 'c2', 'c2@c2.c2', '1231231234'),
(28, 'c1', 'c1', 'c1', 'vvv', 'c1@c1.c1', '1231231231'),
(29, 'c1', 'c1', 'c1', 'c1', 'c1@c1.c1', '1231231231'),
(30, 'c2', 'c2', 'c2', 'c2', 'c2@c2.c2', '1231231231');

-- --------------------------------------------------------

--
-- Table structure for table `client_request`
--

CREATE TABLE IF NOT EXISTS `client_request` (
  `trasport` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `vehical_type` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `package_number` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_request`
--

INSERT INTO `client_request` (`trasport`, `date`, `vehical_type`, `name`, `phone`, `address`, `package_number`) VALUES
('gub', '2018-11-28', 'Two Wheeler', 'v1', '1231231231', 'ujie', '136324'),
('gun', '2018-11-29', 'Three Wheeler', 'v1', '3213213211', 'ujire', '252611');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `name` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `phone`, `message`) VALUES
('Veerappan', 'ariveerappa@gmail.co', '7022478282', 'good'),
('Veerappan', 'ariveerappa@gmail.co', '7022478282', 'goalway'),
('aa mm', 'malgeashwini4@gmail.', '1234567898', 'dgdsf bdsgs');

-- --------------------------------------------------------

--
-- Table structure for table `distributor`
--

CREATE TABLE IF NOT EXISTS `distributor` (
  `dist_id` varchar(10) NOT NULL,
  `dname` varchar(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phno` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributor`
--

INSERT INTO `distributor` (`dist_id`, `dname`, `username`, `password`, `email`, `phno`) VALUES
('104529', 'd1', 'd1', 'd1', 'd1@d1.com', '1231231232'),
('189555', 'd2', 'd2', 'd2', 'd2@d2.d2', '1231231233'),
('156654', 'd1', 'd1', 'd1', 'd1@d1.d1', '1231234561');

-- --------------------------------------------------------

--
-- Table structure for table `distributor_request`
--

CREATE TABLE IF NOT EXISTS `distributor_request` (
  `trasport` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `qty` int(11) NOT NULL,
  `vehical_type` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pincode` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributor_request`
--


-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE IF NOT EXISTS `review` (
  `name` varchar(50) NOT NULL,
  `feedback` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`name`, `feedback`) VALUES
('Veerappan', 'better'),
('aa', 'good qty'),
('aa', 'fdgh jhjh'),
('v1', 'good update');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE IF NOT EXISTS `vehicles` (
  `vno` int(11) NOT NULL DEFAULT '0',
  `vtype` varchar(20) DEFAULT NULL,
  `vehical_stock` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`vno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`vno`, `vtype`, `vehical_stock`) VALUES
(1, 'Two Wheeler ', '10'),
(2, 'Three Wheeler ', '29'),
(3, 'Four Wheeler ', '19'),
(4, 'Eight Wheeler', '20');

-- --------------------------------------------------------

--
-- Table structure for table `vendor1`
--

CREATE TABLE IF NOT EXISTS `vendor1` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `vname` varchar(30) NOT NULL,
  `username` varchar(22) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phno` varchar(10) NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `vendor1`
--

INSERT INTO `vendor1` (`vid`, `vname`, `username`, `password`, `email`, `phno`) VALUES
(4, 'v1', 'v1', 'v1', 'v1@v1.v1', '1231231236'),
(5, 'v2', 'v2', 'v2', 'v2@v2.v2', '1231231237');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE IF NOT EXISTS `warehouse` (
  `wid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`wid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`wid`, `username`, `password`) VALUES
(1, 'warehouse', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_request`
--

CREATE TABLE IF NOT EXISTS `warehouse_request` (
  `trasport` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `qty` int(11) NOT NULL,
  `vehical_type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pincode` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `warehouse_request`
--

